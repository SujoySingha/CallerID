package com.callerid.bd.util

/**
 * Utility for parsing, validating, and formatting Bangladeshi phone numbers.
 * Truecaller API expects standard international E.164 numbers or clean queries.
 */
object PhoneNumberFormatter {

    const val COUNTRY_CODE_BD = "BD"
    const val COUNTRY_DIAL_CODE_BD = "+880"

    enum class Operator(val brandName: String, val prefix: String) {
        GRAMEENPHONE("Grameenphone", "017"),
        SKITTO("Grameenphone (Skitto)", "013"),
        BANGLALINK_19("Banglalink", "019"),
        BANGLALINK_14("Banglalink", "014"),
        ROBI("Robi", "018"),
        AIRTEL("Robi (Airtel)", "016"),
        TELETALK("Teletalk", "015"),
        UNKNOWN("Unknown Operator", "")
    }

    data class FormattedNumber(
        val rawNumber: String,
        val cleanNational: String,       // e.g. "01712345678"
        val internationalE164: String,   // e.g. "+8801712345678"
        val operator: Operator,
        val isValidBdNumber: Boolean
    )

    /**
     * Cleans and standardizes any incoming Bangladeshi phone number string.
     * Handles inputs like:
     * - "01712345678"
     * - "+880 1712-345678"
     * - "8801712345678"
     * - "008801712345678"
     */
    fun formatBdNumber(rawInput: String?): FormattedNumber {
        if (rawInput.isNullOrBlank()) {
            return FormattedNumber(
                rawNumber = "",
                cleanNational = "",
                internationalE164 = "",
                operator = Operator.UNKNOWN,
                isValidBdNumber = false
            )
        }

        // Remove all whitespace, hyphens, and parenthesis
        var cleaned = rawInput.trim().replace(Regex("[\s\-\(\)]"), "")

        // Normalize leading international prefixes
        when {
            cleaned.startsWith("+880") -> cleaned = cleaned.removePrefix("+880")
            cleaned.startsWith("880") -> cleaned = cleaned.removePrefix("880")
            cleaned.startsWith("00880") -> cleaned = cleaned.removePrefix("00880")
            cleaned.startsWith("0") -> cleaned = cleaned.removePrefix("0")
        }

        // Now cleaned should be 10 digits starting with 13, 14, 15, 16, 17, 18, 19
        val isValidLength = cleaned.length == 10 && cleaned.all { it.isDigit() }
        val prefix = if (cleaned.length >= 2) "0" + cleaned.substring(0, 2) else ""

        val operator = when (prefix) {
            "013" -> Operator.SKITTO
            "017" -> Operator.GRAMEENPHONE
            "014" -> Operator.BANGLALINK_14
            "019" -> Operator.BANGLALINK_19
            "016" -> Operator.AIRTEL
            "018" -> Operator.ROBI
            "015" -> Operator.TELETALK
            else -> Operator.UNKNOWN
        }

        val isValidBd = isValidLength && operator != Operator.UNKNOWN
        val national = if (isValidLength) "0$cleaned" else rawInput
        val international = if (isValidLength) "+880$cleaned" else rawInput

        return FormattedNumber(
            rawNumber = rawInput,
            cleanNational = national,
            internationalE164 = international,
            operator = operator,
            isValidBdNumber = isValidBd
        )
    }
}