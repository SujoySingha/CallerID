package com.callerid.bd

import android.app.Application
import com.callerid.bd.data.api.TruecallerApiService
import com.callerid.bd.data.local.CallerDatabase
import com.callerid.bd.data.pref.DataStoreManager
import com.callerid.bd.data.repository.CallerRepository
import com.callerid.bd.notification.CallerNotificationHelper
import kotlinx.coroutines.runBlocking

class CallerIdApplication : Application() {

    lateinit var database: CallerDatabase
        private set

    lateinit var dataStoreManager: DataStoreManager
        private set

    lateinit var apiService: TruecallerApiService
        private set

    lateinit var repository: CallerRepository
        private set

    lateinit var notificationHelper: CallerNotificationHelper
        private set

    override fun onCreate() {
        super.onCreate()

        dataStoreManager = DataStoreManager(this)
        database = CallerDatabase.getInstance(this)
        notificationHelper = CallerNotificationHelper(this)

        // Initialize Retrofit with dynamic token provider from DataStore
        apiService = TruecallerApiService.createClient(
            tokenProvider = {
                runBlocking {
                    dataStoreManager.getInstallationIdSynchronously()
                }
            },
            isDebug = BuildConfig.DEBUG
        )

        repository = CallerRepository(
            callerDao = database.callerDao(),
            apiService = apiService
        )
    }
}