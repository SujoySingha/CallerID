package com.callerid.bd.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CallerDao {

    @Query("SELECT * FROM caller_cache WHERE phone_number = :phoneNumber LIMIT 1")
    suspend fun getCallerByNumber(phoneNumber: String): CallerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(caller: CallerEntity)

    @Query("SELECT * FROM caller_cache ORDER BY cached_at DESC LIMIT :limit")
    fun getRecentCallers(limit: Int = 50): Flow<List<CallerEntity>>

    @Query("DELETE FROM caller_cache WHERE phone_number = :phoneNumber")
    suspend fun deleteByNumber(phoneNumber: String)

    @Query("DELETE FROM caller_cache WHERE cached_at < :expirationTimestamp")
    suspend fun deleteExpiredCallers(expirationTimestamp: Long): Int

    @Query("DELETE FROM caller_cache")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM caller_cache")
    suspend fun getCacheCount(): Int
}