package com.callerid.bd.service

import android.telecom.Call
import android.telecom.CallScreeningService
import android.util.Log
import com.callerid.bd.CallerIdApplication
import com.callerid.bd.data.repository.CallerLookupResult
import com.callerid.bd.notification.CallerNotificationHelper
import kotlinx.coroutines.*

/**
 * Modern CallScreeningService (Android 10+ / API 29+).
 * Requires user to select this app as the default "Caller ID & Spam" app in system settings.
 */
class BdCallScreeningService : CallScreeningService() {

    companion object {
        private const val TAG = "BdCallScreeningService"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onScreenCall(callDetails: Call.Details) {
        // Only screen incoming calls
        if (callDetails.callDirection != Call.Details.DIRECTION_INCOMING) {
            return
        }

        val handle = callDetails.handle
        val rawNumber = handle?.schemeSpecificPart ?: ""

        Log.d(TAG, "Incoming call intercepted from: $rawNumber")

        if (rawNumber.isBlank()) {
            allowCallSilently(callDetails)
            return
        }

        val app = application as? CallerIdApplication
        val repository = app?.repository
        val notificationHelper = app?.notificationHelper

        // Immediately respond to system telecom to avoid blocking the call ring
        val responseBuilder = CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)

        respondToCall(callDetails, responseBuilder.build())

        // Trigger asynchronous Truecaller resolution in background scope
        serviceScope.launch {
            if (repository == null || notificationHelper == null) return@launch

            // Step 1: Initial quick alert (Unknown / Searching...)
            notificationHelper.showSearchingNotification(rawNumber)

            // Step 2: Resolve Caller Identity from Cache or Truecaller API
            when (val result = repository.lookupCaller(rawNumber)) {
                is CallerLookupResult.Success -> {
                    val caller = result.caller
                    Log.i(TAG, "Caller Identified: ${caller.callerName} (Spam: ${caller.isSpam})")

                    // Show High-Priority Heads-up Notification with Caller Name
                    notificationHelper.showCallerIdentifiedNotification(
                        caller = caller,
                        isFromCache = result.isFromCache
                    )
                }
                is CallerLookupResult.NotFound -> {
                    notificationHelper.showUnknownCallerNotification(rawNumber)
                }
                is CallerLookupResult.Error -> {
                    notificationHelper.showLookupErrorNotification(rawNumber, result.message)
                }
            }
        }
    }

    private fun allowCallSilently(callDetails: Call.Details) {
        val response = CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .build()
        respondToCall(callDetails, response)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}