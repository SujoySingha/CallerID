package com.callerid.bd.data.api

import com.callerid.bd.data.api.models.TruecallerSearchResponse
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface TruecallerApiService {

    /**
     * Query Truecaller Non-EU Search API
     * @param phoneNumber Formatted number (+88017XXXXXXXX)
     * @param countryCode Country Code (Default: "BD")
     * @param type Search type (Default: "4")
     * @param encoding Encoding parameter
     */
    @GET("v2/search")
    suspend fun searchNumber(
        @Query("q") phoneNumber: String,
        @Query("countryCode") countryCode: String = "BD",
        @Query("type") type: String = "4",
        @Query("placement") placement: String = "SEARCHRESULTS,HISTORY,DETAILS",
        @Query("encoding") encoding: String = "json"
    ): Response<TruecallerSearchResponse>

    companion object {
        const val BASE_URL = "https://search5-noneu.truecaller.com/"

        /**
         * Builds the OkHttpClient with custom Truecaller authentication & headers
         */
        fun createClient(
            tokenProvider: () -> String?,
            isDebug: Boolean = false
        ): TruecallerApiService {

            val authInterceptor = Interceptor { chain ->
                val original = chain.request()
                val token = tokenProvider() ?: ""

                val requestBuilder = original.newBuilder()
                    .header("Authorization", "Bearer $token")
                    .header("User-Agent", "Truecaller/13.44.6 (Android;13)")
                    .header("Accept", "application/json")
                    .header("Accept-Encoding", "gzip, deflate")
                    .header("Connection", "keep-alive")
                    .header("clientVersion", "13.44.6")

                chain.proceed(requestBuilder.build())
            }

            val loggingInterceptor = HttpLoggingInterceptor().apply {
                level = if (isDebug) {
                    HttpLoggingInterceptor.Level.BODY
                } else {
                    HttpLoggingInterceptor.Level.BASIC
                }
            }

            val okHttpClient = OkHttpClient.Builder()
                .addInterceptor(authInterceptor)
                .addInterceptor(loggingInterceptor)
                // Short timeout is critical: we must answer the call screen in under 4 seconds!
                .connectTimeout(4, TimeUnit.SECONDS)
                .readTimeout(4, TimeUnit.SECONDS)
                .writeTimeout(4, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build()

            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return retrofit.create(TruecallerApiService::class.java)
        }
    }
}