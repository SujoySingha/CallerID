package com.callerid.bd.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import com.callerid.bd.CallerIdApplication
import com.callerid.bd.data.repository.CallerLookupResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Fallback BroadcastReceiver for devices where CallScreeningService is not active.
 */
class IncomingCallReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "IncomingCallReceiver"
        private var lastState = TelephonyManager.EXTRA_STATE_IDLE
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

        val app = context.applicationContext as? CallerIdApplication ?: return
        val notificationHelper = app.notificationHelper
        val repository = app.repository

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (lastState != TelephonyManager.EXTRA_STATE_RINGING && !incomingNumber.isNullOrBlank()) {
                    Log.d(TAG, "Ringing state detected for: $incomingNumber")

                    CoroutineScope(Dispatchers.IO).launch {
                        notificationHelper.showSearchingNotification(incomingNumber)
                        when (val result = repository.lookupCaller(incomingNumber)) {
                            is CallerLookupResult.Success -> {
                                notificationHelper.showCallerIdentifiedNotification(
                                    caller = result.caller,
                                    isFromCache = result.isFromCache
                                )
                            }
                            is CallerLookupResult.NotFound -> {
                                notificationHelper.showUnknownCallerNotification(incomingNumber)
                            }
                            is CallerLookupResult.Error -> {
                                notificationHelper.showLookupErrorNotification(
                                    incomingNumber,
                                    result.message
                                )
                            }
                        }
                    }
                }
            }

            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                // Call answered: dismiss the heads-up notification
                Log.d(TAG, "Call answered (OFFHOOK)")
                notificationHelper.dismissNotification()
            }

            TelephonyManager.EXTRA_STATE_IDLE -> {
                // Call ended or missed: dismiss the notification
                Log.d(TAG, "Call ended (IDLE)")
                notificationHelper.dismissNotification()
            }
        }

        lastState = state
    }
}