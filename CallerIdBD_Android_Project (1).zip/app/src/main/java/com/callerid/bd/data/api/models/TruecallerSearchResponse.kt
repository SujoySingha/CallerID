package com.callerid.bd.data.api.models

import com.google.gson.annotations.SerializedName

/**
 * Root response object returned by https://search5-noneu.truecaller.com/v2/search
 */
data class TruecallerSearchResponse(
    @SerializedName("data") val data: List<SearchContactData>? = null,
    @SerializedName("message") val message: String? = null,
    @SerializedName("status") val status: Int? = null
) {
    val primaryContact: SearchContactData?
        get() = data?.firstOrNull()
}

data class SearchContactData(
    @SerializedName("id") val id: String? = null,
    @SerializedName("name") val name: String? = null,
    @SerializedName("altName") val altName: String? = null,
    @SerializedName("access") val access: String? = null,
    @SerializedName("gender") val gender: String? = null,
    @SerializedName("image") val image: String? = null,
    @SerializedName("score") val score: Double? = null,
    @SerializedName("phones") val phones: List<PhoneDetail>? = null,
    @SerializedName("addresses") val addresses: List<AddressDetail>? = null,
    @SerializedName("spamInfo") val spamInfo: SpamInfo? = null,
    @SerializedName("badges") val badges: List<String>? = null
) {
    val displayName: String
        get() = name?.takeIf { it.isNotBlank() }
            ?: altName?.takeIf { it.isNotBlank() }
            ?: "Unknown Caller"

    val isSpam: Boolean
        get() = (spamInfo?.spamScore ?: 0) > 0 || spamInfo?.spamType != null

    val carrierName: String?
        get() = phones?.firstOrNull()?.carrier

    val locationName: String?
        get() = addresses?.firstOrNull()?.let {
            listOfNotNull(it.city, it.countryCode).joinToString(", ")
        }
}

data class PhoneDetail(
    @SerializedName("e164Format") val e164Format: String? = null,
    @SerializedName("numberType") val numberType: String? = null,
    @SerializedName("nationalFormat") val nationalFormat: String? = null,
    @SerializedName("dialingCode") val dialingCode: Int? = null,
    @SerializedName("countryCode") val countryCode: String? = null,
    @SerializedName("carrier") val carrier: String? = null,
    @SerializedName("type") val type: Int? = null
)

data class AddressDetail(
    @SerializedName("city") val city: String? = null,
    @SerializedName("countryCode") val countryCode: String? = null,
    @SerializedName("timeZone") val timeZone: String? = null
)

data class SpamInfo(
    @SerializedName("spamScore") val spamScore: Int? = null,
    @SerializedName("spamType") val spamType: String? = null,
    @SerializedName("spamCategories") val spamCategories: List<String>? = null
)