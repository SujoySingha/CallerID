package com.callerid.bd.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.callerid.bd.CallerIdApplication
import com.callerid.bd.data.api.SendOtpRequest
import com.callerid.bd.data.api.TruecallerAuthService
import com.callerid.bd.data.api.VerifyOtpRequest
import com.callerid.bd.databinding.ActivityTruecallerLoginBinding
import com.callerid.bd.util.PhoneNumberFormatter
import kotlinx.coroutines.launch
import java.util.UUID

class TruecallerLoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTruecallerLoginBinding
    private val authService = TruecallerAuthService.create()

    private var currentRequestId: String? = null
    private var normalizedPhoneNational: String = ""
    private var normalizedPhoneE164: String = ""
    private val deviceId = UUID.randomUUID().toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTruecallerLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
    }

    private fun setupUI() {
        binding.btnSendOtp.setOnClickListener {
            handleSendOtp()
        }

        binding.btnVerifyOtp.setOnClickListener {
            handleVerifyOtp()
        }

        binding.btnResend.setOnClickListener {
            handleSendOtp()
        }
    }

    private fun handleSendOtp() {
        val input = binding.etPhoneNumber.text.toString().trim()
        val formatted = PhoneNumberFormatter.formatBdNumber(input)

        if (!formatted.isValidBdNumber) {
            binding.etPhoneNumber.error = "সঠিক বাংলাদেশি মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)"
            return
        }

        normalizedPhoneE164 = formatted.internationalE164
        // 10 digits without leading zero: e.g. "17XXXXXXXX"
        normalizedPhoneNational = formatted.cleanNational.removePrefix("0")

        binding.progressBar.visibility = View.VISIBLE
        binding.btnSendOtp.isEnabled = false

        lifecycleScope.launch {
            try {
                val request = SendOtpRequest(
                    countryCode = "BD",
                    dialingCode = 880,
                    phoneNumber = normalizedPhoneNational,
                    phone = normalizedPhoneE164,
                    deviceId = deviceId
                )

                val response = authService.sendOtp(request)
                binding.progressBar.visibility = View.GONE
                binding.btnSendOtp.isEnabled = true

                if (response.isSuccessful && response.body() != null) {
                    val body = response.body()!!
                    currentRequestId = body.requestId

                    Toast.makeText(
                        this@TruecallerLoginActivity,
                        "OTP কোড পাঠানো হয়েছে আপনার নম্বরে!",
                        Toast.LENGTH_LONG
                    ).show()

                    // Transition to OTP Input View
                    binding.layoutPhoneInput.visibility = View.GONE
                    binding.layoutOtpInput.visibility = View.VISIBLE
                    binding.tvOtpSentSubtext.text = "৬ ডিজিটের কোডটি লিখুন যা ${formatted.cleanNational} এ এসেছে:"
                } else {
                    val error = response.errorBody()?.string() ?: "OTP পাঠানো যায়নি"
                    Toast.makeText(this@TruecallerLoginActivity, "ব্যর্থ: $error", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.progressBar.visibility = View.GONE
                binding.btnSendOtp.isEnabled = true
                Toast.makeText(this@TruecallerLoginActivity, "ইন্টারনেট ত্রুটি: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleVerifyOtp() {
        val otp = binding.etOtpCode.text.toString().trim()
        if (otp.length != 6) {
            binding.etOtpCode.error = "৬ ডিজিটের OTP কোড দিন"
            return
        }

        val reqId = currentRequestId
        if (reqId.isNullOrBlank()) {
            Toast.makeText(this, "অনুগ্রহ করে আবার OTP পাঠান", Toast.LENGTH_SHORT).show()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnVerifyOtp.isEnabled = false

        lifecycleScope.launch {
            try {
                val request = VerifyOtpRequest(
                    countryCode = "BD",
                    dialingCode = 880,
                    phoneNumber = normalizedPhoneNational,
                    requestId = reqId,
                    otpCode = otp
                )

                val response = authService.verifyOtp(request)
                binding.progressBar.visibility = View.GONE
                binding.btnVerifyOtp.isEnabled = true

                if (response.isSuccessful && response.body() != null) {
                    val body = response.body()!!
                    val token = body.installationId

                    if (!token.isNullOrBlank()) {
                        // Auto-Save Token into DataStore!
                        val app = application as CallerIdApplication
                        app.dataStoreManager.saveInstallationId(token)

                        Toast.makeText(
                            this@TruecallerLoginActivity,
                            "🎉 অভিনন্দন! লগইন সফল এবং টোকেন সেভ হয়েছে!",
                            Toast.LENGTH_LONG
                        ).show()

                        finish() // Return to Main Screen
                    } else {
                        Toast.makeText(this@TruecallerLoginActivity, "টোকেন পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@TruecallerLoginActivity, "ভুল OTP কোড! আবার চেষ্টা করুন।", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.progressBar.visibility = View.GONE
                binding.btnVerifyOtp.isEnabled = true
                Toast.makeText(this@TruecallerLoginActivity, "ত্রুটি: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}