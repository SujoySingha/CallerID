package com.callerid.bd.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "caller_cache",
    indices = [
        Index(value = ["phone_number"], unique = true),
        Index(value = ["cached_at"])
    ]
)
data class CallerEntity(
    @PrimaryKey
    @ColumnInfo(name = "phone_number")
    val phoneNumber: String, // Normalized E.164 (+8801XXXXXXXXX)

    @ColumnInfo(name = "caller_name")
    val callerName: String,

    @ColumnInfo(name = "carrier")
    val carrier: String?,

    @ColumnInfo(name = "location")
    val location: String?,

    @ColumnInfo(name = "is_spam")
    val isSpam: Boolean = false,

    @ColumnInfo(name = "spam_score")
    val spamScore: Int = 0,

    @ColumnInfo(name = "spam_type")
    val spamType: String? = null,

    @ColumnInfo(name = "avatar_url")
    val avatarUrl: String? = null,

    @ColumnInfo(name = "cached_at")
    val cachedAt: Long = System.currentTimeMillis()
) {
    /**
     * Checks if this cached entry is older than specified TTL (default 30 days)
     */
    fun isExpired(ttlMillis: Long = 30L * 24 * 60 * 60 * 1000): Boolean {
        return System.currentTimeMillis() - cachedAt > ttlMillis
    }
}