package com.callerid.bd.ui

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.callerid.bd.CallerIdApplication
import com.callerid.bd.databinding.ActivityMainBinding
import com.callerid.bd.data.repository.CallerLookupResult
import com.callerid.bd.util.PhoneNumberFormatter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val roleRequestLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            Toast.makeText(this, "Call Screening Role Granted!", Toast.LENGTH_SHORT).show()
            updateRoleStatus()
        } else {
            Toast.makeText(this, "Role not granted. Caller ID may not work.", Toast.LENGTH_LONG).show()
        }
    }

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            Toast.makeText(this, "All permissions granted!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupButtons()
        checkAndRequestPermissions()
        updateRoleStatus()
        observeTokenStatus()
    }

    private fun setupButtons() {
        binding.btnSetDefaultApp.setOnClickListener {
            requestCallScreeningRole()
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnTestLookup.setOnClickListener {
            performTestLookup()
        }
    }

    private fun performTestLookup() {
        val inputNumber = binding.etTestNumber.text.toString().trim()
        if (inputNumber.isBlank()) {
            binding.etTestNumber.error = "Enter a Bangladeshi phone number"
            return
        }

        val app = application as CallerIdApplication
        binding.btnTestLookup.isEnabled = false
        binding.tvTestResult.text = "Searching Truecaller & Local Cache..."

        lifecycleScope.launch {
            when (val result = app.repository.lookupCaller(inputNumber)) {
                is CallerLookupResult.Success -> {
                    val caller = result.caller
                    val source = if (result.isFromCache) "Local Room Cache" else "Truecaller API"
                    binding.tvTestResult.text = """
                        ✅ Name: ${caller.callerName}
                        📱 Number: ${caller.phoneNumber}
                        🏢 Operator: ${caller.carrier ?: "N/A"}
                        📍 Location: ${caller.location ?: "Bangladesh"}
                        ⚠️ Is Spam: ${caller.isSpam} (Score: ${caller.spamScore})
                        ⚡ Source: $source
                    """.trimIndent()

                    // Also trigger the Heads-up Notification to preview it!
                    app.notificationHelper.showCallerIdentifiedNotification(
                        caller,
                        result.isFromCache
                    )
                }
                is CallerLookupResult.NotFound -> {
                    binding.tvTestResult.text = "❌ No name found for this number on Truecaller."
                }
                is CallerLookupResult.Error -> {
                    binding.tvTestResult.text = "⚠️ Error: ${result.message}"
                }
            }
            binding.btnTestLookup.isEnabled = true
        }
    }

    private fun requestCallScreeningRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            if (roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                if (!roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING)
                    roleRequestLauncher.launch(intent)
                } else {
                    Toast.makeText(this, "Already set as default Call Screening app!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun updateRoleStatus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            val isHeld = roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
            binding.tvRoleStatus.text = if (isHeld) "Role: Active (Default Screening App)" else "Role: Not Granted"
        }
    }

    private fun observeTokenStatus() {
        val app = application as CallerIdApplication
        lifecycleScope.launch {
            val token = app.dataStoreManager.installationIdFlow.first()
            if (token.isNullOrBlank()) {
                binding.tvTokenStatus.text = "⚠️ Token: Missing (Go to Settings to paste Installation ID)"
            } else {
                binding.tvTokenStatus.text = "✅ Truecaller Token: Configured (${token.take(8)}...)"
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = mutableListOf(
            android.Manifest.permission.READ_PHONE_STATE,
            android.Manifest.permission.READ_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            permissionsLauncher.launch(missing.toTypedArray())
        }
    }
}