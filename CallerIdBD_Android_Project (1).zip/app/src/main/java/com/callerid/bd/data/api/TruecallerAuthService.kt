package com.callerid.bd.data.api

import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface TruecallerAuthService {

    @POST("v2/sendOtp")
    @Headers(
        "Content-Type: application/json; charset=UTF-8",
        "User-Agent: Truecaller/13.44.6 (Android;13)",
        "clientVersion: 13.44.6"
    )
    suspend fun sendOtp(
        @Body request: SendOtpRequest
    ): Response<SendOtpResponse>

    @POST("v2/verifyOtp")
    @Headers(
        "Content-Type: application/json; charset=UTF-8",
        "User-Agent: Truecaller/13.44.6 (Android;13)",
        "clientVersion: 13.44.6"
    )
    suspend fun verifyOtp(
        @Body request: VerifyOtpRequest
    ): Response<VerifyOtpResponse>

    companion object {
        const val AUTH_BASE_URL = "https://account-asia-south1.truecaller.com/"

        fun create(): TruecallerAuthService {
            val client = OkHttpClient.Builder()
                .addInterceptor(HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                })
                .build()

            return Retrofit.Builder()
                .baseUrl(AUTH_BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(TruecallerAuthService::class.java)
        }
    }
}

data class SendOtpRequest(
    @SerializedName("countryCode") val countryCode: String = "BD",
    @SerializedName("dialingCode") val dialingCode: Int = 880,
    @SerializedName("phoneNumber") val phoneNumber: String, // 10 digits without leading 0 (e.g. 1722591778)
    @SerializedName("phone") val phone: String, // +8801722591778
    @SerializedName("deviceId") val deviceId: String,
    @SerializedName("language") val language: String = "en",
    @SerializedName("installationDetails") val installationDetails: Map<String, Any> = mapOf(
        "app" to mapOf("buildVersion" to 1344006, "majorVersion" to 13, "minorVersion" to 44, "store" to "google"),
        "device" to mapOf("manufacturer" to "Samsung", "model" to "SM-S918B", "osName" to "Android", "osVersion" to "14")
    )
)

data class SendOtpResponse(
    @SerializedName("status") val status: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("requestId") val requestId: String?,
    @SerializedName("tokenTtl") val tokenTtl: Int?
)

data class VerifyOtpRequest(
    @SerializedName("countryCode") val countryCode: String = "BD",
    @SerializedName("dialingCode") val dialingCode: Int = 880,
    @SerializedName("phoneNumber") val phoneNumber: String,
    @SerializedName("requestId") val requestId: String,
    @SerializedName("token") val otpCode: String
)

data class VerifyOtpResponse(
    @SerializedName("status") val status: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("installationId") val installationId: String?,
    @SerializedName("userId") val userId: String?,
    @SerializedName("ttl") val ttl: Long?
)