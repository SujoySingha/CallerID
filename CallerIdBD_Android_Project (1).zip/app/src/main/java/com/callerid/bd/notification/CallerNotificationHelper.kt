package com.callerid.bd.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import com.callerid.bd.R
import com.callerid.bd.data.local.CallerEntity
import com.callerid.bd.ui.MainActivity
import com.callerid.bd.util.PhoneNumberFormatter

class CallerNotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "bd_caller_id_channel"
        const val CHANNEL_NAME = "Real-time Caller ID"
        const val NOTIFICATION_ID = 1001
        const val ACTION_DISMISS = "com.callerid.bd.ACTION_DISMISS_NOTIFICATION"
    }

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows real-time Truecaller identity for incoming calls"
                enableLights(true)
                lightColor = Color.BLUE
                enableVibration(false) // Call ringtone already vibrates
                setShowBadge(false)
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showSearchingNotification(phoneNumber: String) {
        val formatted = PhoneNumberFormatter.formatBdNumber(phoneNumber)
        val operatorName = formatted.operator.brandName

        val contentIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_caller_id)
            .setContentTitle("Incoming Call...")
            .setContentText("${formatted.cleanNational} ($operatorName)")
            .setSubText("Truecaller BD")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .setOngoing(false)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    fun showCallerIdentifiedNotification(caller: CallerEntity, isFromCache: Boolean) {
        val contentIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val formatted = PhoneNumberFormatter.formatBdNumber(caller.phoneNumber)
        val sourceBadge = if (isFromCache) "[Cached]" else "[Truecaller]"
        val subText = listOfNotNull(caller.carrier, caller.location).joinToString(" • ")

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_caller_id)
            .setContentTitle(caller.callerName)
            .setContentText("${formatted.cleanNational}  $sourceBadge")
            .setSubText(subText)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .setOngoing(false)

        if (caller.isSpam) {
            builder.setColor(Color.RED)
            builder.setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle("⚠️ SPAM CALLER: ${caller.callerName}")
                    .bigText("Spam Score: ${caller.spamScore}% • Type: ${caller.spamType ?: "Telemarketing"}
${formatted.cleanNational} (${caller.carrier ?: "BD"})")
            )
        } else {
            builder.setColor(Color.parseColor("#0072BC"))
            builder.setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle(caller.callerName)
                    .bigText("${formatted.cleanNational}
Operator: ${caller.carrier ?: formatted.operator.brandName}
Location: ${caller.location ?: "Bangladesh"}")
            )
        }

        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    fun showUnknownCallerNotification(phoneNumber: String) {
        val formatted = PhoneNumberFormatter.formatBdNumber(phoneNumber)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_caller_id)
            .setContentTitle("Unknown Caller")
            .setContentText("${formatted.cleanNational} (${formatted.operator.brandName})")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    fun showLookupErrorNotification(phoneNumber: String, errorReason: String) {
        val formatted = PhoneNumberFormatter.formatBdNumber(phoneNumber)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_caller_id)
            .setContentTitle("Incoming: ${formatted.cleanNational}")
            .setContentText("Lookup failed: $errorReason")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    fun dismissNotification() {
        notificationManager.cancel(NOTIFICATION_ID)
    }
}