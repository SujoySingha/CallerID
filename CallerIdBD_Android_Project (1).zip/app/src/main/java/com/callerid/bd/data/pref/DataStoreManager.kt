package com.callerid.bd.data.pref

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "caller_id_prefs")

class DataStoreManager(private val context: Context) {

    companion object {
        val KEY_INSTALLATION_ID = stringPreferencesKey("truecaller_installation_id")
        val KEY_COUNTRY_CODE = stringPreferencesKey("country_code")
        val KEY_OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val KEY_SPAM_BLOCK_ENABLED = booleanPreferencesKey("spam_block_enabled")
    }

    val installationIdFlow: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[KEY_INSTALLATION_ID]
    }

    val countryCodeFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_COUNTRY_CODE] ?: "BD"
    }

    val isOverlayEnabledFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_OVERLAY_ENABLED] ?: false
    }

    suspend fun saveInstallationId(token: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_INSTALLATION_ID] = token.trim()
        }
    }

    suspend fun getInstallationIdSynchronously(): String? {
        return context.dataStore.data.first()[KEY_INSTALLATION_ID]
    }

    suspend fun saveCountryCode(countryCode: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_COUNTRY_CODE] = countryCode.uppercase().trim()
        }
    }

    suspend fun setOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_OVERLAY_ENABLED] = enabled
        }
    }

    suspend fun clearToken() {
        context.dataStore.edit { preferences ->
            preferences.remove(KEY_INSTALLATION_ID)
        }
    }
}