package com.callerid.bd.data.repository

import android.util.Log
import com.callerid.bd.data.api.TruecallerApiService
import com.callerid.bd.data.local.CallerDao
import com.callerid.bd.data.local.CallerEntity
import com.callerid.bd.util.PhoneNumberFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class CallerLookupResult {
    data class Success(
        val caller: CallerEntity,
        val isFromCache: Boolean
    ) : CallerLookupResult()

    data class NotFound(val formattedNumber: String) : CallerLookupResult()
    data class Error(val message: String, val code: Int? = null) : CallerLookupResult()
}

class CallerRepository(
    private val callerDao: CallerDao,
    private val apiService: TruecallerApiService
) {
    companion object {
        private const val TAG = "CallerRepository"
    }

    /**
     * Resolves caller identity for an incoming number.
     * Strategy:
     * 1. Format number to Bangladeshi standard E.164 (+8801XXXXXXXXX).
     * 2. Query Room Cache -> Return immediately if found and not expired.
     * 3. Make Truecaller API network call.
     * 4. Parse result, persist to Room DB, and return.
     */
    suspend fun lookupCaller(rawNumber: String): CallerLookupResult = withContext(Dispatchers.IO) {
        val formatted = PhoneNumberFormatter.formatBdNumber(rawNumber)
        val targetNumber = if (formatted.isValidBdNumber) {
            formatted.internationalE164
        } else {
            rawNumber
        }

        // Step 1: Check Local Cache First (Speed < 5ms)
        try {
            val cachedCaller = callerDao.getCallerByNumber(targetNumber)
            if (cachedCaller != null && !cachedCaller.isExpired()) {
                Log.d(TAG, "Cache HIT for $targetNumber: ${cachedCaller.callerName}")
                return@withContext CallerLookupResult.Success(cachedCaller, isFromCache = true)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cache read error: ${e.message}", e)
        }

        // Step 2: Fetch from Truecaller API
        try {
            Log.d(TAG, "Cache MISS for $targetNumber. Querying Truecaller API...")
            val response = apiService.searchNumber(
                phoneNumber = targetNumber,
                countryCode = "BD"
            )

            if (!response.isSuccessful) {
                val errorCode = response.code()
                val errorBody = response.errorBody()?.string()
                Log.e(TAG, "Truecaller API error $errorCode: $errorBody")
                
                // Fallback to operator identification if API fails or token is missing
                if (formatted.isValidBdNumber) {
                    val fallbackEntity = CallerEntity(
                        phoneNumber = targetNumber,
                        callerName = "${formatted.operator.brandName} User",
                        carrier = formatted.operator.brandName,
                        location = "Bangladesh",
                        isSpam = false,
                        spamScore = 0,
                        cachedAt = System.currentTimeMillis()
                    )
                    return@withContext CallerLookupResult.Success(fallbackEntity, isFromCache = false)
                }

                return@withContext when (errorCode) {
                    401 -> CallerLookupResult.Error("Truecaller token expired (401)", 401)
                    429 -> CallerLookupResult.Error("Rate limit reached (429)", 429)
                    else -> CallerLookupResult.Error("API request failed ($errorCode)", errorCode)
                }
            }

            val searchResponse = response.body()
            val contact = searchResponse?.primaryContact

            if (contact != null && !contact.name.isNullOrBlank()) {
                val newEntity = CallerEntity(
                    phoneNumber = targetNumber,
                    callerName = contact.displayName,
                    carrier = contact.carrierName ?: formatted.operator.brandName,
                    location = contact.locationName ?: "Bangladesh",
                    isSpam = contact.isSpam,
                    spamScore = contact.spamInfo?.spamScore ?: 0,
                    spamType = contact.spamInfo?.spamType,
                    avatarUrl = contact.image,
                    cachedAt = System.currentTimeMillis()
                )

                // Persist to local Room database for next time
                callerDao.insertOrUpdate(newEntity)
                Log.d(TAG, "Successfully resolved and cached: ${newEntity.callerName}")

                return@withContext CallerLookupResult.Success(newEntity, isFromCache = false)
            } else {
                Log.d(TAG, "No contact details found in Truecaller for $targetNumber")
                return@withContext CallerLookupResult.NotFound(targetNumber)
            }

        } catch (e: java.net.SocketTimeoutException) {
            Log.w(TAG, "Network timeout searching $targetNumber")
            return@withContext CallerLookupResult.Error("Network timeout")
        } catch (e: java.net.UnknownHostException) {
            Log.w(TAG, "No internet connection")
            return@withContext CallerLookupResult.Error("No internet connection")
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error searching $targetNumber: ${e.message}", e)
            return@withContext CallerLookupResult.Error(e.message ?: "Unknown lookup error")
        }
    }
}